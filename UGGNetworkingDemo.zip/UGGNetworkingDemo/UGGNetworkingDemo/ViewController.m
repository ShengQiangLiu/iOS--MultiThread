//
//  ViewController.m
//  UGGNetworkingDemo
//
//  Created by admin on 15/7/24.
//  Copyright (c) 2015年 ShengQiangLiu. All rights reserved.
//

#import "ViewController.h"
#import "UGGHTTPSessionManager.h"
#import "AFNetworking.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    

    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
}

- (IBAction)btnClick:(id)sender {
//    @"https://api.app.net/stream/0/posts/stream/global"
    [[UGGHTTPSessionManager manager] GET:@"http://img1.imgtn.bdimg.com/it/u=651986609,1848241502&fm=21&gp=0.jpg" parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        static int i = 0;
        NSLog(@"%@ %d", responseObject, i++);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@", error);
        
    }];
    
//    [[AFHTTPSessionManager manager] GET:@"http://img1.imgtn.bdimg.com/it/u=651986609,1848241502&fm=21&gp=0.jpg" parameters:@"" success:^void(NSURLSessionDataTask * task, id responseObject) {
//        NSLog(@"%@", responseObject);
//    } failure:^void(NSURLSessionDataTask * task, NSError * error) {
//        NSLog(@"%@", error);
//    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
