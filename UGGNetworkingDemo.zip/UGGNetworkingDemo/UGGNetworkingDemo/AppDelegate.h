//
//  AppDelegate.h
//  UGGNetworkingDemo
//
//  Created by admin on 15/7/24.
//  Copyright (c) 2015年 ShengQiangLiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

