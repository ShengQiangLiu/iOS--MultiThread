//
//  UGGHTTPSessionManager.h
//  UGGNetworkingDemo
//
//  Created by admin on 15/7/24.
//  Copyright (c) 2015年 ShengQiangLiu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UGGHTTPSessionManager : NSObject

///---------------------
/// @name Initialization
///---------------------
+ (instancetype)manager;
- (instancetype)initWithBaseURL:(NSURL *)url;
- (instancetype)initWithBaseURL:(NSURL *)url sessionConfiguration:(NSURLSessionConfiguration *)configuration;

///---------------------------
/// @name Making HTTP Requests
///---------------------------
/**
 @param URLString ...
 @param parameters ...
 @param success ...
 @param failure ...
 **/
- (NSURLSessionDataTask *)GET:(NSString *)URLString
                   parameters:(id)parameters
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                      failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

/**
 @param URLString ...
 @param parameters ...
 @param success ...
 @param failure ...
 **/
- (NSURLSessionDataTask *)POST:(NSString *)URLString parameters:(id)parameters success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;


@end
